public class Main {

	public static void main(String[] args) {
	Scanner in=new Scanner(System.in);
		StudentGroup s=new StudentGroup(in.nextInt());
   		s.getStudents();
		s.setStudents();
		s.getStudent(in.nextInt());
		s.setStudent(in.nextLine(),in.nextInt());
		s.addFirst(in.nextLine());
		s.addLast(in.nextLine());
		s.add(in.nextLine(),in.nextInt());
		s.remove(in.nextInt());
		s.remove(int.nextLine());
		s.removeFromIndex(in.nextInt());
		//You may test that your code works find here
		//Please check that your code works and has no 
		//compilation problems before to submit
	}

}
